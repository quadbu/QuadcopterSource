/*********************************************************************
 * glcd_menu.h
 ********************************************************************/

//***********************************************************
//* Externals
//***********************************************************

extern void LCD_Display_Text (uint16_t menuitem, const unsigned char* font,uint16_t x, uint16_t y);
extern void gLCDprint_Menu_P(const char *s, const unsigned char* font,uint16_t x, uint16_t y);





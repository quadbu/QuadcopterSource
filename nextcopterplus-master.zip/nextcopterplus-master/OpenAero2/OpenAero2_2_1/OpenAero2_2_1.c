/*
 * OpenAero2_2_1.c
 *
 * Created: 18/03/2014 10:02:58 AM
 *  Author: thompson
 */ 


#include <avr/io.h>

int main(void)
{
    while(1)
    {
        //TODO:: Please write your application code 
    }
}